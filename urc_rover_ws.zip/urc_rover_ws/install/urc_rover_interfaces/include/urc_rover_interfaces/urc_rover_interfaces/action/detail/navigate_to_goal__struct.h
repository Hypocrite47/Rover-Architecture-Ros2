// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from urc_rover_interfaces:action/NavigateToGoal.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "urc_rover_interfaces/action/navigate_to_goal.h"


#ifndef URC_ROVER_INTERFACES__ACTION__DETAIL__NAVIGATE_TO_GOAL__STRUCT_H_
#define URC_ROVER_INTERFACES__ACTION__DETAIL__NAVIGATE_TO_GOAL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'waypoint_type'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_Goal
{
  float target_x;
  float target_y;
  rosidl_runtime_c__String waypoint_type;
} urc_rover_interfaces__action__NavigateToGoal_Goal;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_Goal.
typedef struct urc_rover_interfaces__action__NavigateToGoal_Goal__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_Goal__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_Result
{
  bool success;
  float final_x;
  float final_y;
  rosidl_runtime_c__String message;
} urc_rover_interfaces__action__NavigateToGoal_Result;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_Result.
typedef struct urc_rover_interfaces__action__NavigateToGoal_Result__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_Result__Sequence;

// Constants defined in the message

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_Feedback
{
  float current_x;
  float current_y;
  float distance_remaining;
} urc_rover_interfaces__action__NavigateToGoal_Feedback;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_Feedback.
typedef struct urc_rover_interfaces__action__NavigateToGoal_Feedback__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_Feedback__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "urc_rover_interfaces/action/detail/navigate_to_goal__struct.h"

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  urc_rover_interfaces__action__NavigateToGoal_Goal goal;
} urc_rover_interfaces__action__NavigateToGoal_SendGoal_Request;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_SendGoal_Request.
typedef struct urc_rover_interfaces__action__NavigateToGoal_SendGoal_Request__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_SendGoal_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} urc_rover_interfaces__action__NavigateToGoal_SendGoal_Response;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_SendGoal_Response.
typedef struct urc_rover_interfaces__action__NavigateToGoal_SendGoal_Response__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_SendGoal_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  urc_rover_interfaces__action__NavigateToGoal_SendGoal_Event__request__MAX_SIZE = 1
};
// response
enum
{
  urc_rover_interfaces__action__NavigateToGoal_SendGoal_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_SendGoal_Event
{
  service_msgs__msg__ServiceEventInfo info;
  urc_rover_interfaces__action__NavigateToGoal_SendGoal_Request__Sequence request;
  urc_rover_interfaces__action__NavigateToGoal_SendGoal_Response__Sequence response;
} urc_rover_interfaces__action__NavigateToGoal_SendGoal_Event;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_SendGoal_Event.
typedef struct urc_rover_interfaces__action__NavigateToGoal_SendGoal_Event__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_SendGoal_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_SendGoal_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} urc_rover_interfaces__action__NavigateToGoal_GetResult_Request;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_GetResult_Request.
typedef struct urc_rover_interfaces__action__NavigateToGoal_GetResult_Request__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_GetResult_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "urc_rover_interfaces/action/detail/navigate_to_goal__struct.h"

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_GetResult_Response
{
  int8_t status;
  urc_rover_interfaces__action__NavigateToGoal_Result result;
} urc_rover_interfaces__action__NavigateToGoal_GetResult_Response;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_GetResult_Response.
typedef struct urc_rover_interfaces__action__NavigateToGoal_GetResult_Response__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_GetResult_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
// already included above
// #include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  urc_rover_interfaces__action__NavigateToGoal_GetResult_Event__request__MAX_SIZE = 1
};
// response
enum
{
  urc_rover_interfaces__action__NavigateToGoal_GetResult_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_GetResult_Event
{
  service_msgs__msg__ServiceEventInfo info;
  urc_rover_interfaces__action__NavigateToGoal_GetResult_Request__Sequence request;
  urc_rover_interfaces__action__NavigateToGoal_GetResult_Response__Sequence response;
} urc_rover_interfaces__action__NavigateToGoal_GetResult_Event;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_GetResult_Event.
typedef struct urc_rover_interfaces__action__NavigateToGoal_GetResult_Event__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_GetResult_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_GetResult_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "urc_rover_interfaces/action/detail/navigate_to_goal__struct.h"

/// Struct defined in action/NavigateToGoal in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__NavigateToGoal_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  urc_rover_interfaces__action__NavigateToGoal_Feedback feedback;
} urc_rover_interfaces__action__NavigateToGoal_FeedbackMessage;

// Struct for a sequence of urc_rover_interfaces__action__NavigateToGoal_FeedbackMessage.
typedef struct urc_rover_interfaces__action__NavigateToGoal_FeedbackMessage__Sequence
{
  urc_rover_interfaces__action__NavigateToGoal_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__NavigateToGoal_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // URC_ROVER_INTERFACES__ACTION__DETAIL__NAVIGATE_TO_GOAL__STRUCT_H_
