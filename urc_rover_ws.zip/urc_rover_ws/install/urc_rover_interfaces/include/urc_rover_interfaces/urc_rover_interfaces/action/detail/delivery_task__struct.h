// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from urc_rover_interfaces:action/DeliveryTask.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "urc_rover_interfaces/action/delivery_task.h"


#ifndef URC_ROVER_INTERFACES__ACTION__DETAIL__DELIVERY_TASK__STRUCT_H_
#define URC_ROVER_INTERFACES__ACTION__DETAIL__DELIVERY_TASK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'object_id'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_Goal
{
  float pickup_x;
  float pickup_y;
  float delivery_x;
  float delivery_y;
  rosidl_runtime_c__String object_id;
} urc_rover_interfaces__action__DeliveryTask_Goal;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_Goal.
typedef struct urc_rover_interfaces__action__DeliveryTask_Goal__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_Goal__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_Result
{
  bool success;
  rosidl_runtime_c__String message;
} urc_rover_interfaces__action__DeliveryTask_Result;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_Result.
typedef struct urc_rover_interfaces__action__DeliveryTask_Result__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_Result__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'status'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_Feedback
{
  rosidl_runtime_c__String status;
  float progress;
} urc_rover_interfaces__action__DeliveryTask_Feedback;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_Feedback.
typedef struct urc_rover_interfaces__action__DeliveryTask_Feedback__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_Feedback__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "urc_rover_interfaces/action/detail/delivery_task__struct.h"

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  urc_rover_interfaces__action__DeliveryTask_Goal goal;
} urc_rover_interfaces__action__DeliveryTask_SendGoal_Request;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_SendGoal_Request.
typedef struct urc_rover_interfaces__action__DeliveryTask_SendGoal_Request__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_SendGoal_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} urc_rover_interfaces__action__DeliveryTask_SendGoal_Response;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_SendGoal_Response.
typedef struct urc_rover_interfaces__action__DeliveryTask_SendGoal_Response__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_SendGoal_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  urc_rover_interfaces__action__DeliveryTask_SendGoal_Event__request__MAX_SIZE = 1
};
// response
enum
{
  urc_rover_interfaces__action__DeliveryTask_SendGoal_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_SendGoal_Event
{
  service_msgs__msg__ServiceEventInfo info;
  urc_rover_interfaces__action__DeliveryTask_SendGoal_Request__Sequence request;
  urc_rover_interfaces__action__DeliveryTask_SendGoal_Response__Sequence response;
} urc_rover_interfaces__action__DeliveryTask_SendGoal_Event;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_SendGoal_Event.
typedef struct urc_rover_interfaces__action__DeliveryTask_SendGoal_Event__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_SendGoal_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_SendGoal_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} urc_rover_interfaces__action__DeliveryTask_GetResult_Request;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_GetResult_Request.
typedef struct urc_rover_interfaces__action__DeliveryTask_GetResult_Request__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_GetResult_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "urc_rover_interfaces/action/detail/delivery_task__struct.h"

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_GetResult_Response
{
  int8_t status;
  urc_rover_interfaces__action__DeliveryTask_Result result;
} urc_rover_interfaces__action__DeliveryTask_GetResult_Response;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_GetResult_Response.
typedef struct urc_rover_interfaces__action__DeliveryTask_GetResult_Response__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_GetResult_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
// already included above
// #include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  urc_rover_interfaces__action__DeliveryTask_GetResult_Event__request__MAX_SIZE = 1
};
// response
enum
{
  urc_rover_interfaces__action__DeliveryTask_GetResult_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_GetResult_Event
{
  service_msgs__msg__ServiceEventInfo info;
  urc_rover_interfaces__action__DeliveryTask_GetResult_Request__Sequence request;
  urc_rover_interfaces__action__DeliveryTask_GetResult_Response__Sequence response;
} urc_rover_interfaces__action__DeliveryTask_GetResult_Event;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_GetResult_Event.
typedef struct urc_rover_interfaces__action__DeliveryTask_GetResult_Event__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_GetResult_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_GetResult_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "urc_rover_interfaces/action/detail/delivery_task__struct.h"

/// Struct defined in action/DeliveryTask in the package urc_rover_interfaces.
typedef struct urc_rover_interfaces__action__DeliveryTask_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  urc_rover_interfaces__action__DeliveryTask_Feedback feedback;
} urc_rover_interfaces__action__DeliveryTask_FeedbackMessage;

// Struct for a sequence of urc_rover_interfaces__action__DeliveryTask_FeedbackMessage.
typedef struct urc_rover_interfaces__action__DeliveryTask_FeedbackMessage__Sequence
{
  urc_rover_interfaces__action__DeliveryTask_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} urc_rover_interfaces__action__DeliveryTask_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // URC_ROVER_INTERFACES__ACTION__DETAIL__DELIVERY_TASK__STRUCT_H_
