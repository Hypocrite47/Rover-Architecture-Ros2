// generated from rosidl_generator_c/resource/idl.h.em
// with input from urc_rover_interfaces:action/DeliveryTask.idl
// generated code does not contain a copyright notice

#ifndef URC_ROVER_INTERFACES__ACTION__DELIVERY_TASK_H_
#define URC_ROVER_INTERFACES__ACTION__DELIVERY_TASK_H_

#include "urc_rover_interfaces/action/detail/delivery_task__struct.h"
#include "urc_rover_interfaces/action/detail/delivery_task__functions.h"
#include "urc_rover_interfaces/action/detail/delivery_task__type_support.h"

#endif  // URC_ROVER_INTERFACES__ACTION__DELIVERY_TASK_H_
