// generated from rosidl_generator_c/resource/idl.h.em
// with input from urc_rover_interfaces:action/NavigateToGoal.idl
// generated code does not contain a copyright notice

#ifndef URC_ROVER_INTERFACES__ACTION__NAVIGATE_TO_GOAL_H_
#define URC_ROVER_INTERFACES__ACTION__NAVIGATE_TO_GOAL_H_

#include "urc_rover_interfaces/action/detail/navigate_to_goal__struct.h"
#include "urc_rover_interfaces/action/detail/navigate_to_goal__functions.h"
#include "urc_rover_interfaces/action/detail/navigate_to_goal__type_support.h"

#endif  // URC_ROVER_INTERFACES__ACTION__NAVIGATE_TO_GOAL_H_
