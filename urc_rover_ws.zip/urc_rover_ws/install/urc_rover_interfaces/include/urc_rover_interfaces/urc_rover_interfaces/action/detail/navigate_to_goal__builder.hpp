// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from urc_rover_interfaces:action/NavigateToGoal.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "urc_rover_interfaces/action/navigate_to_goal.hpp"


#ifndef URC_ROVER_INTERFACES__ACTION__DETAIL__NAVIGATE_TO_GOAL__BUILDER_HPP_
#define URC_ROVER_INTERFACES__ACTION__DETAIL__NAVIGATE_TO_GOAL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "urc_rover_interfaces/action/detail/navigate_to_goal__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_Goal_waypoint_type
{
public:
  explicit Init_NavigateToGoal_Goal_waypoint_type(::urc_rover_interfaces::action::NavigateToGoal_Goal & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_Goal waypoint_type(::urc_rover_interfaces::action::NavigateToGoal_Goal::_waypoint_type_type arg)
  {
    msg_.waypoint_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Goal msg_;
};

class Init_NavigateToGoal_Goal_target_y
{
public:
  explicit Init_NavigateToGoal_Goal_target_y(::urc_rover_interfaces::action::NavigateToGoal_Goal & msg)
  : msg_(msg)
  {}
  Init_NavigateToGoal_Goal_waypoint_type target_y(::urc_rover_interfaces::action::NavigateToGoal_Goal::_target_y_type arg)
  {
    msg_.target_y = std::move(arg);
    return Init_NavigateToGoal_Goal_waypoint_type(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Goal msg_;
};

class Init_NavigateToGoal_Goal_target_x
{
public:
  Init_NavigateToGoal_Goal_target_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_Goal_target_y target_x(::urc_rover_interfaces::action::NavigateToGoal_Goal::_target_x_type arg)
  {
    msg_.target_x = std::move(arg);
    return Init_NavigateToGoal_Goal_target_y(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_Goal>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_Goal_target_x();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_Result_message
{
public:
  explicit Init_NavigateToGoal_Result_message(::urc_rover_interfaces::action::NavigateToGoal_Result & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_Result message(::urc_rover_interfaces::action::NavigateToGoal_Result::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Result msg_;
};

class Init_NavigateToGoal_Result_final_y
{
public:
  explicit Init_NavigateToGoal_Result_final_y(::urc_rover_interfaces::action::NavigateToGoal_Result & msg)
  : msg_(msg)
  {}
  Init_NavigateToGoal_Result_message final_y(::urc_rover_interfaces::action::NavigateToGoal_Result::_final_y_type arg)
  {
    msg_.final_y = std::move(arg);
    return Init_NavigateToGoal_Result_message(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Result msg_;
};

class Init_NavigateToGoal_Result_final_x
{
public:
  explicit Init_NavigateToGoal_Result_final_x(::urc_rover_interfaces::action::NavigateToGoal_Result & msg)
  : msg_(msg)
  {}
  Init_NavigateToGoal_Result_final_y final_x(::urc_rover_interfaces::action::NavigateToGoal_Result::_final_x_type arg)
  {
    msg_.final_x = std::move(arg);
    return Init_NavigateToGoal_Result_final_y(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Result msg_;
};

class Init_NavigateToGoal_Result_success
{
public:
  Init_NavigateToGoal_Result_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_Result_final_x success(::urc_rover_interfaces::action::NavigateToGoal_Result::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_NavigateToGoal_Result_final_x(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_Result>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_Result_success();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_Feedback_distance_remaining
{
public:
  explicit Init_NavigateToGoal_Feedback_distance_remaining(::urc_rover_interfaces::action::NavigateToGoal_Feedback & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_Feedback distance_remaining(::urc_rover_interfaces::action::NavigateToGoal_Feedback::_distance_remaining_type arg)
  {
    msg_.distance_remaining = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Feedback msg_;
};

class Init_NavigateToGoal_Feedback_current_y
{
public:
  explicit Init_NavigateToGoal_Feedback_current_y(::urc_rover_interfaces::action::NavigateToGoal_Feedback & msg)
  : msg_(msg)
  {}
  Init_NavigateToGoal_Feedback_distance_remaining current_y(::urc_rover_interfaces::action::NavigateToGoal_Feedback::_current_y_type arg)
  {
    msg_.current_y = std::move(arg);
    return Init_NavigateToGoal_Feedback_distance_remaining(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Feedback msg_;
};

class Init_NavigateToGoal_Feedback_current_x
{
public:
  Init_NavigateToGoal_Feedback_current_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_Feedback_current_y current_x(::urc_rover_interfaces::action::NavigateToGoal_Feedback::_current_x_type arg)
  {
    msg_.current_x = std::move(arg);
    return Init_NavigateToGoal_Feedback_current_y(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_Feedback>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_Feedback_current_x();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_SendGoal_Request_goal
{
public:
  explicit Init_NavigateToGoal_SendGoal_Request_goal(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Request goal(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Request msg_;
};

class Init_NavigateToGoal_SendGoal_Request_goal_id
{
public:
  Init_NavigateToGoal_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_SendGoal_Request_goal goal_id(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_NavigateToGoal_SendGoal_Request_goal(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Request>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_SendGoal_Request_goal_id();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_SendGoal_Response_stamp
{
public:
  explicit Init_NavigateToGoal_SendGoal_Response_stamp(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Response stamp(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Response msg_;
};

class Init_NavigateToGoal_SendGoal_Response_accepted
{
public:
  Init_NavigateToGoal_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_SendGoal_Response_stamp accepted(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_NavigateToGoal_SendGoal_Response_stamp(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Response>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_SendGoal_Response_accepted();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_SendGoal_Event_response
{
public:
  explicit Init_NavigateToGoal_SendGoal_Event_response(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event response(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event msg_;
};

class Init_NavigateToGoal_SendGoal_Event_request
{
public:
  explicit Init_NavigateToGoal_SendGoal_Event_request(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event & msg)
  : msg_(msg)
  {}
  Init_NavigateToGoal_SendGoal_Event_response request(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_NavigateToGoal_SendGoal_Event_response(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event msg_;
};

class Init_NavigateToGoal_SendGoal_Event_info
{
public:
  Init_NavigateToGoal_SendGoal_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_SendGoal_Event_request info(::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_NavigateToGoal_SendGoal_Event_request(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_SendGoal_Event>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_SendGoal_Event_info();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_GetResult_Request_goal_id
{
public:
  Init_NavigateToGoal_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Request goal_id(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_GetResult_Request>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_GetResult_Request_goal_id();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_GetResult_Response_result
{
public:
  explicit Init_NavigateToGoal_GetResult_Response_result(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Response result(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Response msg_;
};

class Init_NavigateToGoal_GetResult_Response_status
{
public:
  Init_NavigateToGoal_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_GetResult_Response_result status(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_NavigateToGoal_GetResult_Response_result(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_GetResult_Response>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_GetResult_Response_status();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_GetResult_Event_response
{
public:
  explicit Init_NavigateToGoal_GetResult_Event_response(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event response(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event msg_;
};

class Init_NavigateToGoal_GetResult_Event_request
{
public:
  explicit Init_NavigateToGoal_GetResult_Event_request(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event & msg)
  : msg_(msg)
  {}
  Init_NavigateToGoal_GetResult_Event_response request(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_NavigateToGoal_GetResult_Event_response(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event msg_;
};

class Init_NavigateToGoal_GetResult_Event_info
{
public:
  Init_NavigateToGoal_GetResult_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_GetResult_Event_request info(::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_NavigateToGoal_GetResult_Event_request(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_GetResult_Event>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_GetResult_Event_info();
}

}  // namespace urc_rover_interfaces


namespace urc_rover_interfaces
{

namespace action
{

namespace builder
{

class Init_NavigateToGoal_FeedbackMessage_feedback
{
public:
  explicit Init_NavigateToGoal_FeedbackMessage_feedback(::urc_rover_interfaces::action::NavigateToGoal_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::urc_rover_interfaces::action::NavigateToGoal_FeedbackMessage feedback(::urc_rover_interfaces::action::NavigateToGoal_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_FeedbackMessage msg_;
};

class Init_NavigateToGoal_FeedbackMessage_goal_id
{
public:
  Init_NavigateToGoal_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigateToGoal_FeedbackMessage_feedback goal_id(::urc_rover_interfaces::action::NavigateToGoal_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_NavigateToGoal_FeedbackMessage_feedback(msg_);
  }

private:
  ::urc_rover_interfaces::action::NavigateToGoal_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::urc_rover_interfaces::action::NavigateToGoal_FeedbackMessage>()
{
  return urc_rover_interfaces::action::builder::Init_NavigateToGoal_FeedbackMessage_goal_id();
}

}  // namespace urc_rover_interfaces

#endif  // URC_ROVER_INTERFACES__ACTION__DETAIL__NAVIGATE_TO_GOAL__BUILDER_HPP_
