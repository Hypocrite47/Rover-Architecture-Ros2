#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from std_msgs.msg import String
from urc_rover_interfaces.action import NavigateToGoal
import time

class AutonomousNav(Node):
    def __init__(self):
        super().__init__('autonomous_nav')
        
        # Action client for navigation
        self._nav_client = ActionClient(self, NavigateToGoal, 'navigate_to_goal')
        
        # Publishers
        self.led_pub = self.create_publisher(String, '/led_status', 10)
        
        # Waypoints: 2 GNSS, 2 Vision (keep away from walls)
        self.waypoints = [
            {'x': 2.5, 'y': 2.5, 'type': 'gnss', 'name': 'GNSS_Point_1'},
            {'x': 8.5, 'y': 2.5, 'type': 'vision', 'name': 'Vision_Target_1'},
            {'x': 8.5, 'y': 8.5, 'type': 'gnss', 'name': 'GNSS_Point_2'},
            {'x': 2.5, 'y': 8.5, 'type': 'vision', 'name': 'Vision_Target_2'},
        ]
        
        self.get_logger().info('Autonomous Navigation Ready!')
    
    def run_mission(self):
        self.get_logger().info('Starting Autonomous Navigation...')
        
        # Set LED to RED (Autonomous mode)
        self.led_pub.publish(String(data='AUTONOMOUS'))
        
        for i, waypoint in enumerate(self.waypoints):
            self.get_logger().info(f"\n--- Waypoint {i+1}/4: {waypoint['name']} ---")
            self.get_logger().info(f"Type: {waypoint['type'].upper()}")
            
            # Navigate to waypoint
            if not self.navigate_to(waypoint['x'], waypoint['y'], waypoint['type']):
                self.get_logger().error(f"Failed to reach {waypoint['name']}")
                continue
            
            # Reached target - Set LED to GREEN
            self.led_pub.publish(String(data='TARGET_REACHED'))
            self.get_logger().info(f"Reached {waypoint['name']}!")
            
            # Simulate target verification
            if waypoint['type'] == 'vision':
                self.get_logger().info('Vision system detected target marker')
            else:
                self.get_logger().info('GNSS coordinates confirmed')
            
            # Wait before next waypoint
            time.sleep(3)
            
            # Back to autonomous (RED)
            if i < len(self.waypoints) - 1:
                self.led_pub.publish(String(data='AUTONOMOUS'))
        
        # Mission complete - Set LED to BLUE (Manual mode)
        self.led_pub.publish(String(data='MANUAL'))
        self.get_logger().info('\nAutonomous Navigation Complete!')
    
    def navigate_to(self, x, y, waypoint_type):
        self.get_logger().info(f'Navigating to ({x}, {y})...')
        
        # Wait for action server
        self._nav_client.wait_for_server()
        
        # Create goal
        goal = NavigateToGoal.Goal()
        goal.target_x = x
        goal.target_y = y
        goal.waypoint_type = waypoint_type
        
        # Send goal
        future = self._nav_client.send_goal_async(goal, feedback_callback=self.feedback_callback)
        rclpy.spin_until_future_complete(self, future)
        
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Goal rejected')
            return False
        
        # Wait for result
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        
        result = result_future.result().result
        return result.success
    
    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(
            f'Position: ({feedback.current_x:.2f}, {feedback.current_y:.2f}), '
            f'Distance: {feedback.distance_remaining:.2f}',
            throttle_duration_sec=1.0
        )

def main(args=None):
    rclpy.init(args=args)
    node = AutonomousNav()
    
    try:
        # Wait for other nodes
        time.sleep(2)
        node.run_mission()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
