#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer, GoalResponse, CancelResponse
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from urc_rover_interfaces.action import NavigateToGoal
import math
import time

class NavigationController(Node):
    def __init__(self):
        super().__init__('navigation_controller')
        
        # Publisher to move turtle
        self.cmd_pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        
        # Subscriber to get turtle position
        self.pose_sub = self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        
        # Current position
        self.current_pose = Pose()
        self.pose_received = False
        
        # Action server for navigation
        self._action_server = ActionServer(
            self,
            NavigateToGoal,
            'navigate_to_goal',
            execute_callback=self.execute_navigation,
            goal_callback=self.goal_callback,
            cancel_callback=self.cancel_callback
        )
        
        # Parameters
        self.declare_parameter('linear_speed', 2.0)
        self.declare_parameter('angular_speed', 4.0)
        self.declare_parameter('distance_tolerance', 0.2)
        
        self.get_logger().info('Navigation Controller Ready!')
    
    def pose_callback(self, msg):
        """Update current pose"""
        self.current_pose = msg
        self.pose_received = True
    
    def goal_callback(self, goal_request):
        """Accept or reject navigation goal"""
        self.get_logger().info(f'Goal request: ({goal_request.target_x:.2f}, {goal_request.target_y:.2f})')
        return GoalResponse.ACCEPT
    
    def cancel_callback(self, goal_handle):
        """Handle cancellation request"""
        self.get_logger().info('Cancel requested')
        return CancelResponse.ACCEPT
    
    async def execute_navigation(self, goal_handle):
        """Execute navigation to target"""
        goal = goal_handle.request
        feedback = NavigateToGoal.Feedback()
        
        self.get_logger().info(f'Navigating to ({goal.target_x:.2f}, {goal.target_y:.2f})')
        
        # Wait for first pose
        timeout = 5.0
        start_wait = time.time()
        while not self.pose_received:
            if time.time() - start_wait > timeout:
                self.get_logger().error('Timeout waiting for pose')
                goal_handle.abort()
                return NavigateToGoal.Result(success=False, message='No pose data')
            time.sleep(0.1)
        
        # Get parameters
        linear_speed = self.get_parameter('linear_speed').value
        angular_speed = self.get_parameter('angular_speed').value
        tolerance = self.get_parameter('distance_tolerance').value
        
        # Navigation loop
        rate = self.create_rate(20)  # 20 Hz for smoother control
        
        while rclpy.ok():
            # Check cancellation
            if goal_handle.is_cancel_requested:
                self.stop()
                goal_handle.canceled()
                return NavigateToGoal.Result(success=False, message='Cancelled')
            
            # Calculate distance and angle to target
            dx = goal.target_x - self.current_pose.x
            dy = goal.target_y - self.current_pose.y
            distance = math.sqrt(dx**2 + dy**2)
            target_angle = math.atan2(dy, dx)
            
            # Publish feedback
            feedback.current_x = self.current_pose.x
            feedback.current_y = self.current_pose.y
            feedback.distance_remaining = distance
            goal_handle.publish_feedback(feedback)
            
            # Check if reached goal
            if distance < tolerance:
                self.stop()
                self.get_logger().info(f'✓ Reached ({self.current_pose.x:.2f}, {self.current_pose.y:.2f})')
                goal_handle.succeed()
                result = NavigateToGoal.Result()
                result.success = True
                result.final_x = self.current_pose.x
                result.final_y = self.current_pose.y
                result.message = 'Success'
                return result
            
            # Calculate angle difference
            angle_diff = self.normalize_angle(target_angle - self.current_pose.theta)
            
            # Create velocity command
            cmd = Twist()
            
            # If angle is significantly off, rotate first
            if abs(angle_diff) > 0.15:  # ~8.6 degrees
                # Rotate in place
                cmd.linear.x = 0.0
                cmd.angular.z = angular_speed if angle_diff > 0 else -angular_speed
                self.get_logger().info(
                    f'Rotating: angle_diff={angle_diff:.2f}rad, distance={distance:.2f}',
                    throttle_duration_sec=1.0
                )
            else:
                # Move forward with course correction
                cmd.linear.x = min(linear_speed, distance * 2.0)  # Slow down when close
                cmd.angular.z = 3.0 * angle_diff  # Proportional control
                self.get_logger().info(
                    f'Moving: dist={distance:.2f}, speed={cmd.linear.x:.2f}',
                    throttle_duration_sec=1.0
                )
            
            self.cmd_pub.publish(cmd)
            
            try:
                rate.sleep()
            except Exception:
                pass
    
    def stop(self):
        """Stop the turtle"""
        cmd = Twist()
        cmd.linear.x = 0.0
        cmd.angular.z = 0.0
        self.cmd_pub.publish(cmd)
        self.get_logger().info('Stopped')
    
    def normalize_angle(self, angle):
        """Normalize angle to [-pi, pi]"""
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

def main(args=None):
    rclpy.init(args=args)
    node = NavigationController()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
